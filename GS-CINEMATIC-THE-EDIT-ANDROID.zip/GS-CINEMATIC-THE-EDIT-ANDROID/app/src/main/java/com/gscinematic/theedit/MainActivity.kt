package com.gscinematic.theedit

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.app.Activity

class MainActivity : Activity() {
    private val gold = 0xFFD7B56D.toInt(); private val bg = 0xFF070707.toInt(); private val card = 0xFF111111.toInt()
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }
    private fun text(s:String,size:Float,bold:Boolean=false):TextView { val t=TextView(this); t.text=s; t.textSize=size; t.setTextColor(0xFFF4F0E8.toInt()); if(bold)t.setTypeface(null,1); t.setPadding(dp(18),dp(8),dp(18),dp(8)); return t }
    private fun button(s:String,on:()->Unit):Button { val b=Button(this); b.text=s; b.setTextColor(0xFF070707); b.setBackgroundColor(gold); b.setOnClickListener{on()}; return b }
    private fun showHome(){
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setBackgroundColor(bg)
        val scroll=ScrollView(this); val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(dp(14),dp(22),dp(14),dp(28))
        val brand=text("GS\nCINEMATIC",34,true); brand.setTextColor(gold); box.addView(brand)
        box.addView(text("THE EDIT",18,true)); box.addView(space(18))
        val hero=text("THIS IS NOT A PORTFOLIO.\nTHIS IS AN EDIT.",30,true); hero.setTextColor(0xFFF4F0E8.toInt()); box.addView(hero)
        box.addView(text("Professional video editing • motion graphics • live animation • VFX",15)); box.addView(space(16))
        box.addView(button("ENTER THE EDIT") { showServices() }); box.addView(space(22))
        box.addView(text("SERVICES",15,true));
        listOf("01  VIDEO EDITING" to "Cuts, pacing, storytelling & cinematic finishing", "02  MOTION / ANIMATION" to "Titles, transitions, graphics & kinetic design", "03  VFX" to "Compositing, cleanup, effects & visual treatment").forEach{ (a,b)-> val c=text("$a\n$b",17,true); c.setBackgroundColor(card); c.setPadding(dp(18),dp(18),dp(18),dp(18)); box.addView(c); box.addView(space(10)) }
        box.addView(text("YOUR STORY. MY TIMELINE.",24,true)); box.addView(space(10)); box.addView(button("WHATSAPP  +91 72648 29708") { open("https://wa.me/917264829708") }); box.addView(space(8)); box.addView(button("OPEN FULL PORTFOLIO") { open("https://gs-cinematicofficial.netlify.app") })
        scroll.addView(box); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }
    private fun showServices(){ showHome() }
    private fun space(h:Int):Space { val s=Space(this); s.minimumHeight=dp(h); return s }
    private fun open(url:String){ startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}
