# GS CINEMATIC — THE EDIT (Android)

Android-first branded app project for GS CINEMATIC.

- App name: GS CINEMATIC — THE EDIT
- Package: com.gscinematic.theedit
- Contact: +91 72648 29708
- Portfolio: https://gs-cinematicofficial.netlify.app

## Build
Open this folder in Android Studio (JDK 17), let Gradle sync, then Build > Build APK(s).

The project is intentionally dependency-light and uses the Android platform UI.
